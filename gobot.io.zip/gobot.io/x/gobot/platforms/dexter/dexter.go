/*
Package dexter contains Gobot drivers for the Dexter Industries robots

This package currently supports the following robots:
- GoPiGo3

For further information refer to Dexter README:
https://gobot.io/x/gobot/blob/master/platforms/dexter/README.md
*/
package dexter
