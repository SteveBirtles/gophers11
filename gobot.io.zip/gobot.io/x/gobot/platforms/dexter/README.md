# Dexter

This package contains the Gobot drivers for the various Dexter Industries (https://www.dexterindustries.com) robots.

This package currently supports the following robots:
- [GoPiGo3](https://www.dexterindustries.com/gopigo3/)
