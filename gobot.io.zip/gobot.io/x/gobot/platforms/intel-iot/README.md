# Intel IoT

This package contains the Gobot adaptor for the [Intel Edison](http://www.intel.com/content/www/us/en/do-it-yourself/edison.html) and [Intel Joule](http://intel.com/joule) IoT platforms.

This package currently supports the following Intel IoT hardware:
- Intel Edison with the Arduino breakout board
- Intel Joule Developer Kit
