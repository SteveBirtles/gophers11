/*
Package edison contains the Gobot adaptor for the Intel Edison.

For further information refer to intel-iot README:
https://github.com/hybridgroup/gobot/blob/master/platforms/intel-iot/edison/README.md
*/
package edison // import "gobot.io/x/gobot/platforms/intel-iot/edison"
