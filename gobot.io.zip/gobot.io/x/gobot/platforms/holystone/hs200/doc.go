// Package hs200 is the Gobot driver for the Holystone HS200 drone.
package hs200 // import "gobot.io/x/gobot/platforms/holystone/hs200"
