// Package holystone contains the Gobot drivers for the Holystone drones.
// Currently only have support for the HS200 drone.
// For more information, go to:
// http://www.holystone.com/product/Holy_Stone_HS200W_FPV_Drone_with_720P_HD_Live_Video_Wifi_Camera_2_4GHz_4CH_6_Axis_Gyro_RC_Quadcopter_with_Altitude_Hold,_Gravity_Sensor_and_Headless_Mode_Function_RTF,_Color_Red-39.html
//
package holystone // import "gobot.io/x/gobot/platforms/holystone"
