// Package dji contains the Gobot drivers for DJI drones.
// Currently only has support for the DJI Tello.
// For more information, go to:
//
package dji // import "gobot.io/x/gobot/platforms/dji"
