/*
Package chip contains the Gobot adaptor for the CHIP and CHIP Pro

For further information refer to the chip README:
https://github.com/hybridgroup/gobot/blob/master/platforms/chip/README.md
*/
package chip // import "gobot.io/x/gobot/platforms/chip"
