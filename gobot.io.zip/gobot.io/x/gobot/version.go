package gobot

const version = "1.12.0"

// Version returns the current Gobot version
func Version() string {
	return version
}
